package com.example.petanqueoscore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class InterfaceActivity extends AppCompatActivity {

    private TextView WelcomeTextView;
    private String username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interface);

        WelcomeTextView = findViewById(R.id.WelcometextView);

        username = getIntent().getStringExtra("username");

        WelcomeTextView.setText("Bienvenue sur ton profil, "+username+" !");
    }
}